package com.omnistock.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.omnistock.app.model.Producto;

import java.util.List;

@Dao
public interface ProductoDao {

    @Insert
    long insertar(Producto producto);

    @Update
    void actualizar(Producto producto);

    @Query("DELETE FROM productos WHERE id = :id")
    void eliminarPorId(int id);

    @Query("SELECT * FROM productos ORDER BY nombre")
    LiveData<List<Producto>> obtenerTodos();

    // Consulta con JOIN: todos los productos de una categoría específica
    @Query("SELECT p.* FROM productos p " +
           "INNER JOIN categorias c ON p.categoria_id = c.id " +
           "WHERE c.id = :categoriaId ORDER BY p.nombre")
    LiveData<List<Producto>> obtenerPorCategoria(int categoriaId);
}
