package com.omnistock.app.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Entidad Producto (lado "N" de la relación 1:N).
 * Es solo el registro de la BD. La lógica de precios NO vive aquí, vive en
 * ProductoBase y sus hijas (Electronico, Ropa, Alimento).
 *
 * onDelete = CASCADE: si se borra una categoría, se borran sus productos.
 */
@Entity(tableName = "productos",
        foreignKeys = @ForeignKey(
                entity = Categoria.class,
                parentColumns = "id",
                childColumns = "categoria_id",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("categoria_id")})
public class Producto {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String nombre;

    @ColumnInfo(name = "precio_base")
    private double precioBase;

    private int stock;

    @ColumnInfo(name = "tipo_producto")
    private String tipoProducto;

    @ColumnInfo(name = "categoria_id")
    private int categoriaId;

    // Datos propios de cada tipo (solo se usan según el tipo_producto)
    @ColumnInfo(name = "fecha_caducidad")
    private long fechaCaducidad;      // Alimento (0 = no aplica)

    @ColumnInfo(name = "temporada_anterior")
    private boolean temporadaAnterior; // Ropa

    public Producto(String nombre, double precioBase, int stock, String tipoProducto, int categoriaId) {
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.stock = stock;
        this.tipoProducto = tipoProducto;
        this.categoriaId = categoriaId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecioBase() { return precioBase; }
    public void setPrecioBase(double precioBase) { this.precioBase = precioBase; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public String getTipoProducto() { return tipoProducto; }
    public void setTipoProducto(String tipoProducto) { this.tipoProducto = tipoProducto; }

    public int getCategoriaId() { return categoriaId; }
    public void setCategoriaId(int categoriaId) { this.categoriaId = categoriaId; }

    public long getFechaCaducidad() { return fechaCaducidad; }
    public void setFechaCaducidad(long fechaCaducidad) { this.fechaCaducidad = fechaCaducidad; }

    public boolean isTemporadaAnterior() { return temporadaAnterior; }
    public void setTemporadaAnterior(boolean temporadaAnterior) { this.temporadaAnterior = temporadaAnterior; }
}
