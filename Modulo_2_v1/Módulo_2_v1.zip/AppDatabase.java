package com.omnistock.app.data;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.omnistock.app.model.Categoria;
import com.omnistock.app.model.Producto;
import com.omnistock.app.model.Usuario;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Base de datos principal de OmniStock (Singleton). Módulo 2: + Categoria y Producto. */
@Database(entities = {Usuario.class, Categoria.class, Producto.class},
        version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UsuarioDao usuarioDao();
    public abstract CategoriaDao categoriaDao();
    public abstract ProductoDao productoDao();

    private static volatile AppDatabase INSTANCE;

    public static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(4);

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "omnistock_db")
                            .addCallback(datosIniciales)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Se ejecuta solo cuando se crea la BD por primera vez
    private static final RoomDatabase.Callback datosIniciales = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            db.execSQL("INSERT INTO usuarios (nombre, pass, rol) VALUES ('admin', 'admin123', 'ADMIN')");
            db.execSQL("INSERT INTO usuarios (nombre, pass, rol) VALUES ('vendedor', 'vende123', 'VENDEDOR')");

            db.execSQL("INSERT INTO categorias (nombre_categoria, descripcion) VALUES ('Electrónica', 'Dispositivos y accesorios electrónicos')");
            db.execSQL("INSERT INTO categorias (nombre_categoria, descripcion) VALUES ('Ropa', 'Prendas de vestir')");
            db.execSQL("INSERT INTO categorias (nombre_categoria, descripcion) VALUES ('Alimentos', 'Productos comestibles')");
        }
    };
}
