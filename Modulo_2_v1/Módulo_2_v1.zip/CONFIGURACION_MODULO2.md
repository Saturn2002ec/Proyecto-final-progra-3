# Configuración Módulo 2

Archivos NUEVOS: model/ (Categoria, Producto, CategoriaConProductos, ProductoBase, Electronico,
Ropa, Alimento, ProductoFactory), data/CategoriaDao, data/ProductoDao, viewmodel/InventarioViewModel,
ui/ProductoAdapter, ui/ProductoDialogFragment, layouts, menu, drawables y colors_inventario.xml.

Archivos que REEMPLAZAN a los del Módulo 1: data/AppDatabase.java, ui/MainActivity.java,
res/layout/activity_main.xml.

## build.gradle (Module: app) -> dependencies (además de las del Módulo 1)
```
implementation "androidx.recyclerview:recyclerview:1.3.2"
implementation "androidx.cardview:cardview:1.0.0"
implementation "com.google.android.material:material:1.11.0"
implementation "androidx.fragment:fragment:1.6.2"
```

## IMPORTANTE
1. La BD cambió (nuevas tablas): DESINSTALA la app del emulador antes de correrla
   (o Device Manager > Wipe Data). Así se vuelve a crear con los usuarios y las categorías iniciales.
2. La MainActivity usa un Toolbar propio, así que en res/values/themes.xml el tema debe ser
   un "NoActionBar", por ejemplo: parent="Theme.Material3.DayNight.NoActionBar"
