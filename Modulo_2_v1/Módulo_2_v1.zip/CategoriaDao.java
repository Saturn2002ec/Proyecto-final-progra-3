package com.omnistock.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;

import com.omnistock.app.model.Categoria;
import com.omnistock.app.model.CategoriaConProductos;

import java.util.List;

@Dao
public interface CategoriaDao {

    @Insert
    long insertar(Categoria categoria);

    // Al borrar la categoría, Room borra sus productos (ForeignKey CASCADE)
    @Delete
    void eliminar(Categoria categoria);

    @Query("SELECT * FROM categorias ORDER BY nombre_categoria")
    LiveData<List<Categoria>> obtenerTodas();

    // Relación 1:N con @Relation
    @Transaction
    @Query("SELECT * FROM categorias ORDER BY nombre_categoria")
    LiveData<List<CategoriaConProductos>> obtenerCategoriasConProductos();
}
