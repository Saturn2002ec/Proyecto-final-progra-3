package com.omnistock.app.model;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

/** Relación 1:N con @Relation: una categoría junto con todos sus productos. */
public class CategoriaConProductos {

    @Embedded
    public Categoria categoria;

    @Relation(parentColumn = "id", entityColumn = "categoria_id")
    public List<Producto> productos;
}
