package com.example.omnistock.data.ui.main;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.omnistock.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tvBienvenidaRol = findViewById(R.id.tvBienvenidaRol);
        Button btnAgregarProducto = findViewById(R.id.btnAgregarProducto);

        String rolUsuario = getIntent().getStringExtra("USER_ROL");
        tvBienvenidaRol.setText("Panel Principal - Rol: " + rolUsuario);

        if ("ADMIN".equals(rolUsuario)) {
            btnAgregarProducto.setVisibility(View.VISIBLE);
        } else {
            btnAgregarProducto.setVisibility(View.GONE);
        }
    }
}