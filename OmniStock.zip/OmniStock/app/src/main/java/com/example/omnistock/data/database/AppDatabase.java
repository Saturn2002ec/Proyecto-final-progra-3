package com.example.omnistock.data.database;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.example.omnistock.data.dao.UsuarioDao;
import com.example.omnistock.data.entity.Usuario;
import java.util.concurrent.Executors;

// Aquí luego agregarás Categoria.class, Producto.class e HistorialVentas.class
@Database(entities = {Usuario.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;
    public abstract UsuarioDao usuarioDao();

    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "omnistock_db"
                            )
                            .addCallback(roomCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Precarga de usuarios iniciales para pruebas
    private static final RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            Executors.newSingleThreadExecutor().execute(() -> {
                UsuarioDao dao = INSTANCE.usuarioDao();
                dao.insertar(new Usuario("admin", "1234", "ADMIN"));
                dao.insertar(new Usuario("vendedor", "1234", "VENDEDOR"));
            });
        }
    };
}